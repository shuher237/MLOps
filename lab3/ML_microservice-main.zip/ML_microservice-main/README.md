## Пример развертывания ML модели в Docker с использованием Flask (REST API) + масштабирование нагрузки через Nginx балансер

https://habr.com/ru/post/548910/


<br/><br/>
---
[![](https://habrastorage.org/webt/gz/gc/i6/gzgci6pivvdnk-gmj-kepml5q9y.gif)](https://yoomoney.ru/to/4100117863420642)
